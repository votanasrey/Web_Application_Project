<?php

namespace App\Http\Controllers;

use App\Models\events;
use App\Models\trees;
use App\Models\members;
use App\Models\partners;
use App\Models\learning;
use Illuminate\Http\Request;

class ApplicationController extends Controller
{
    public function index () {
        $events = events::latest()->paginate(4);
        $trees = trees::latest()->paginate(8);
        return view('application.index')->with(['events' => $events, 'trees' => $trees, 'i' => 1]);
    }

    public function about () {
        $members = members::latest()->paginate(3);
        $partners = partners::latest()->paginate(10);
        return view('application.about')->with(['members' => $members, 'partners' => $partners]);
    }

    public function contact () {
        return view('application.contact');
    }

    public function events () {
        $events = events::latest()->paginate(4);
        return view('application.events')->with('events', $events);
    }

    public function learning () {
        $learning = learning::latest()->paginate(60);
        return view('application.learning')->with('learning', $learning);
    }
}
