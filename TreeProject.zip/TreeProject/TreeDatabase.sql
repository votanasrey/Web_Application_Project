-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jan 01, 2021 at 05:10 AM
-- Server version: 5.7.30
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `tree`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `created_at`, `updated_at`) VALUES
(1, 'Albizia', NULL, NULL),
(2, 'Bombax', NULL, NULL),
(3, 'Mangifera', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organizer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `organizer`, `description`, `startdate`, `enddate`, `created_at`, `updated_at`) VALUES
(1, 'Festival Universe', 'Ossa', 'Happy festival universe 2021, we wish you all the best \r\nParticularly, we provide you 45% off on our shop payments\r\nWish you wealth and prosperity in life, May good luck follow you in every step and your house be filled with happiness. Xin Nian Kuai Le! With each passing moment\r\n', '2020-12-31', '2021-01-01', NULL, NULL),
(2, 'China new year ', 'Votana', 'Happy china new year festival guy\r\nWish you wealth and prosperity in life, May good luck follow you in every step and your house be filled with happiness. Xin Nian Kuai Le! With each passing moment, let us embrace the New Year with a brighter, more colourful, and more joyous future \r\nGet 50% off all the trees', '2021-02-10', '2021-02-11', NULL, NULL),
(3, 'China new year ', 'Votana', 'Happy Khmer new year \r\nGet 50% off all the trees\r\nTo take this wonderful chance, I would like to say Happy Khmer New Year 2021 to all Cambodian people and the rest of the world and wish you all the best for the upcoming Cambodian New Year 2021 to all my friends, colleague, families, beloved readers, and people around the world. Please', '2021-04-13', '2021-04-16', NULL, NULL),
(4, 'Pchum Ben festival ', 'Kemeng', 'Happy Pchum Ben festival\r\nWe have 45% Off on that days\r\nWish you all have a great holiday with your friends and family and be safe!May good luck follow you in every step and your house be filled with happiness. Xin Nian Kuai Le! With each passing moment, let us embrace the New Year with a brighter, more colourful, and more joyous future', '2021-10-10', '2021-10-15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `learnings`
--

CREATE TABLE `learnings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `postdate` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `learnings`
--

INSERT INTO `learnings` (`id`, `title`, `link`, `image`, `description`, `postdate`, `created_at`, `updated_at`) VALUES
(1, 'Tutorial: Multi Grafting Fruit Trees', 'https://www.youtube.com/watch?v=KHy_ypW9CDI', 'https://i.ytimg.com/vi/KHy_ypW9CDI/hq720.jpg?sqp=-oaymwEZCOgCEMoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&rs=AOn4CLAwgx7YWMd9dHMX7r3zDzTcr8m_VQ', 'Beginners guide to multi grafting fruit trees in 10 steps. Grafting can be done by anyone who wants to have a go.\r\nStep 1 Cut out the dead wood 00:18\r\nStep 2 Locate the rootstock 00:58\r\nStep 3: Remove thorns 01:43\r\nStep 4 Wrap the scion in tape 02:01\r\nStep 5 Perform a top Graft 02:32\r\nStep 6: Cut scion into 4cm spear 03:01\r\nStep 7 Cut rootstock to match scion 03:26\r\nStep 8 Fit scion into rootstock 03:46\r\nStep 9 Tape Together 03:50\r\nStep 10 Remove the tape 05:19\r\n', '2018-10-16', NULL, NULL),
(2, 'This Crazy Tree Grows 40 Kinds of Fruit', 'https://www.youtube.com/watch?v=ik3l4U_17bI', 'https://i.ytimg.com/vi/ik3l4U_17bI/hq720.jpg?sqp=-oaymwEZCOgCEMoBSFXyq4qpAwsIARUAAIhCGAFwAQ==&rs=AOn4CLCmYyUlcmdzAKnD7HtWKh-I6zmxFg', 'Sam Van Aken, an artist and professor at Syracuse University, uses \"chip grafting\" to create trees that each bear 40 different varieties of stone fruits, or fruits with pits. The grafting process involves slicing a bit of a branch with a bud from a tree of one of the varieties and inserting it into a slit in a branch on the \"working tree,\" then wrapping the wound with tape until it heals and the bud starts to grow into a new branch.', '2018-10-16', NULL, NULL),
(3, 'Syracuse professor grows 40 different fruits', 'https://www.youtube.com/watch?v=5kO6-PpgZ1M', 'https://i.ytimg.com/vi/5kO6-PpgZ1M/hqdefault.jpg?sqp=-oaymwEZCOADEI4CSFXyq4qpAwsIARUAAIhCGAFwAQ==&rs=AOn4CLBGDBjcL8NIWsgK-sn6F2NAauc3RA', 'Sam Van Aken, an art professor at Syracuse University, grafted the tree over nine years into something of biblical proportions. The \"Tree of 40 Fruits\" contains peaches, plums, nectarines and apricots, all of which are readily edible. Jeff Glor reports.', '2018-10-16', NULL, NULL),
(4, 'WOW!!! Amazing Agriculture Technology', 'https://www.youtube.com/watch?v=D6zBOkS7pgQ', 'https://i.ytimg.com/vi/D6zBOkS7pgQ/hqdefault.jpg?sqp=-oaymwEZCOADEI4CSFXyq4qpAwsIARUAAIhCGAFwAQ==&rs=AOn4CLAhwhoFa93NbpFz090uyMfDvkPwXw', 'WOW!!! Strange Coconut Trees Bonsai\r\n► Support us on: https://top2reviews.com/\r\n\r\nNew Agriculture Technology - The Future Of Agriculture - Subscribe Now: https://goo.gl/agThGD modern agriculture technology in the world.\r\nFollow us:\r\n- G+: https://plus.google.com/1026510239446...\r\n- Amazing Agriculture Community: https://goo.gl/r8VrZZ', '2018-10-19', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `joindate` date NOT NULL,
  `shotdesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `firstname`, `lastname`, `email`, `position`, `image`, `joindate`, `shotdesc`, `created_at`, `updated_at`) VALUES
(1, 'Votana ', 'Srey', 'votana.srey@gmail.com', 'Co-founder', '/images/members/SreyVotana.jpg', '2020-11-25', 'I am a sophomore of NIPTICT institute\r\nCurrently, I am studying at Here in computer science major, and also I am a  Co-founder at E-Tree', NULL, NULL),
(2, 'Ossa ', 'Souen', 'ossa.souen@gmail.com', 'CTO', '/images/members/SoeunOssa.jpg', '2020-11-25', 'I am a sophomore of NIPTICT institute\r\nCurrently, I am studying at Here in computer science major, and also I am a CTO at E-Tree ', NULL, NULL),
(3, 'Kemeng', 'Song', 'Kemeng.song@gmail.com', 'CEO', '/images/members/SongKemeng.jpg', '2020-11-25', 'I am a sophomore of NIPTICT institute\r\nCurrently, I am studying at Here in computer science major, and also I am a CEO at E-Tree ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Votana Srey', 'votana.srey@gmail.com', 'Hi HI HI', '2020-12-31 21:07:23', '2020-12-31 21:07:23'),
(2, 'Votana Srey', 'votana.srey@gmail.com', 'I recommand you ... BYe', '2020-12-31 21:08:03', '2020-12-31 21:08:03');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(16, '2020_12_24_110044_create_users_table', 1),
(17, '2020_12_28_042247_create_events_table', 1),
(18, '2020_12_28_172023_create_trees_table', 1),
(19, '2020_12_29_002214_create_members_table', 1),
(20, '2020_12_29_020819_create_partners_table', 1),
(21, '2020_12_30_075047_create_messages_table', 1),
(22, '2020_12_31_022307_create_learning_table', 1),
(23, '2020_12_31_035821_create_categories_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `partners`
--

CREATE TABLE `partners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `partners`
--

INSERT INTO `partners` (`id`, `name`, `image`, `created_at`, `updated_at`) VALUES
(1, 'NIPTICT', '/images/partners/Niptict.png', NULL, NULL),
(2, 'Smart Axiata', '/images/partners/Smart.png', NULL, NULL),
(3, 'MAFF', '/images/partners/MAFF.jpg', NULL, NULL),
(4, 'PreakLeap', '/images/partners/PreakLeap.jpg', NULL, NULL),
(5, 'Tourism', '/images/partners/Tourism.png', NULL, NULL),
(6, 'Usaid', '/images/partners/usaid.png', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `trees`
--

CREATE TABLE `trees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `total` int(11) NOT NULL,
  `discount` double NOT NULL,
  `shotdesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `longdesc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryId` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trees`
--

INSERT INTO `trees` (`id`, `name`, `price`, `total`, `discount`, `shotdesc`, `longdesc`, `image`, `categoryId`, `created_at`, `updated_at`) VALUES
(1, 'Albizia', 4.9, 21, 5, 'For the Australian tree commonly named \"Albizia\", see Paraserianthes lophantha plants may be called albizzias', 'They are commonly called silk plants, silk trees, or sirises. The obsolete spelling of the generic name – with double \'z\' – is still common, so the plants may be called albizzias. The generic name honors the Italian nobleman Filippo degli Albizzi, who introduced Albizia julibrissin to Europe in the mid-18th.', '/images/trees/Albizia.jpg', 1, NULL, NULL),
(2, 'Anacardium', 3.5, 10, 5, 'the cashews, are a genus of flowering plants in the family Anacardiaceae, native to tropical regions of the Americas.', 'The name Anacardium, originally from the Greek, actually refers to the nut, core or heart of the fruit, which is outwardly located (ana means \"upwards\" and -cardium means \"heart\").', '/images/trees/Anacardium.jpg', 1, NULL, NULL),
(3, 'Bambusa', 6.2, 12, 10, 'BGV works with bamboo and similar resources in rural Cambodia to provide maximum social, ecological and economic benefits to members of rural', 'The name Anacardium, originally from the Greek, actually refers to the nut, core or heart of the fruit, which is outwardly located (ana means \"upwards\" and -cardium means \"heart\").', '/images/trees/Bambusa.jpg', 1, NULL, NULL),
(4, 'Bombax', 3.4, 15, 5, 'Bombax is a genus of mainly tropical trees in the mallow family. They are native to western Africa, the Indian subcontinent, Southeast Asia,', 'Bombax is a genus of mainly tropical trees in the mallow family. They are native to western Africa, the Indian subcontinent, Southeast Asia, and the subtropical regions of East Asia and northern Australia. It is distinguished from the genus Ceiba, which has whiter flowers.\r\n\r\nCommon names for the genus include silk cotton tree, simal, red cotton tree, kapok, and simply bombax. Currently four species are recognised, although many plants have been placed in the genus that were later moved.', '/images/trees/Bombax.jpg', 2, NULL, NULL),
(5, 'Borassus', 4.2, 10, 5, 'Borassus (palmyra palm) is a genus of five species of fan palms, native to tropical regions of Africa, Asia and New Guinea.', 'These massive palms can grow up to 30 m (98 ft) high and have robust trunks with distinct leaf scars; in some species the trunk develops a distinct swelling just below the crown, though for unknown reasons.\r\nThe leaves are fan-shaped, 2–3 m long and with spines along the petiole margins (no spines in B. heineanus). The leaf sheath has a distinct cleft at its base, through which the inflorescences appear; old leaf sheaths are retained on the trunk, but fall away with time.', '/images/trees/Borassus.jpg', 2, NULL, NULL),
(6, 'Mangifera', 6.2, 10, 5, 'Mangifera is a genus of flowering plants in the cashew family, Anacardiaceae', 'Mangifera is a genus of flowering plants in the cashew family, Anacardiaceae. It contains approximately 69 species, with the best-known being the Common Mango (Mangifera indica). The center of diversity is in subtropical and tropical South Asia and Southeast Asia, while the highest number of species occur in India.[3] They are generally canopy trees in lowland rainforests, reaching a height of 30–40 m (98–131 ft)', '/images/trees/Mangifera.jpg', 3, NULL, NULL),
(7, 'Sesbania', 5, 12, 5, 'Sesbania is a genus of flowering plants in the pea family, Fabaceae, and the only genus found in tribe Sesbanieae', 'Sesbania is a genus of flowering plants in the pea family, Fabaceae, and the only genus found in tribe Sesbanieae. Riverhemp is a common name for plants in this genus.[2] Notable species include the rattlebox (Sesbania punicea), spiny sesbania (Sesbania bispinosa), and Sesbania sesban, which is used in cooking. Plants of this genus, some of which are aquatic, can be used in alley cropping to increase the soil\'s nitrogen content. The species of rhizobia responsible for nitrogen fixation in Sesbania rostrata is Azorhizobium caulinodans.\r\n\r\n', '/images/trees/Sesbania.jpg', 3, NULL, NULL),
(8, 'Vatica', 4, 10, 5, 'Vatica is a genus of plants in the family Dipterocarpaceae. Species[edit]. Species of the genus Vatica include: Vatica adenanii Meekiong', 'Vatica is a genus of plants in the family Dipterocarpaceae. Species[edit]. Species of the genus Vatica include: Vatica adenanii Meekiong', '/images/trees/Vatica.jpg', 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `gender` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(450) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `learnings`
--
ALTER TABLE `learnings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trees`
--
ALTER TABLE `trees`
  ADD PRIMARY KEY (`id`),
  ADD KEY `trees_categoryid_foreign` (`categoryId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `learnings`
--
ALTER TABLE `learnings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `partners`
--
ALTER TABLE `partners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `trees`
--
ALTER TABLE `trees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
