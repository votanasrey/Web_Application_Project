<?php

namespace App\Http\Controllers;

use App\Models\Treelist;
use Illuminate\Http\Request;

class TreelistController extends Controller
{
    //
    public function index() {
        $trees = Treelist::latest()->paginate(8);
        return view('application.index')->with('trees', $trees);
    }

}
