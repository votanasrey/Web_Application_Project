<?php

namespace App\Http\Controllers;

use App\Models\events;
use App\Models\Treelist;
use Illuminate\Http\Request;

class EventsController extends Controller
{
    public function index () {
        $events = events::latest()->paginate(8);
        $trees = Treelist::latest()->paginate(8);
        return view('application.index')->with(['events' => $events , 'trees' => $trees]);
    }
}
