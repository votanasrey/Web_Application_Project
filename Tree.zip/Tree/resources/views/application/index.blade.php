@extends('Container.HeaderAndFooter')

@section('CodeHere')
<header>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner" role="listbox">
        <!-- Slide One - Set the background image for this slide in the line below -->
        <div class="carousel-item active" style="background-image: url('/images/KidWithTree.jpg')">
          <div class="carousel-caption">
            <a href="/" class="text-white" style="text-decoration: none;">
              <h3>500 Trees for new kid</h3>
              <p>You can donate money for growing the trees</p>
            </a>
            <a class="btn text-white btn-danger">Donate</a>
            <a href="" class="btn text-white btn-danger">List all donate</a>
          </div>
        </div>
      </div>
    </div>
  </header>

  <!-- Page Content -->
  <div class="container">
    <h1 class="my-4 color">Events comming soon!!!</h1>

    <!-- Marketing Icons Section -->
    <div class="row">
      @foreach ($events as $event)
      <div class="col-lg-3 mb-4">
        <div class="card h-100">
          <h4 class="card-header" style = "color:  #94BD3D;">{{ $event->title }}</h4>
          <div class="card-body">
            <p class="card-text">{{ $event->description }}</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">Learn More</a>
          </div>
        </div>
      </div>
      @endforeach
    </div>
    <!-- /.row -->

    <!-- Portfolio Section -->
    <h1 class="color">Our Top Trees</h1>
    <div class="row">
      @foreach ($trees as $tree)
      <div class="col-lg-3 col-sm-6 portfolio-item">
        <div class="card h-100">
            <a href="#"><img class="card-img-top" src="{{ $tree->image }}" alt="Tree picture"></a>
            <div class="card-body">
              <h4 class="card-title">
                <a href="#">{{ $tree->name }}</a>
              </h4>
              <h5>{{ $tree->price }}<span>$</span></h5>
              <p class="card-text">{{ $tree->description }}</p>
            </div>
            <div class="card-footer">
              <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9733;</small>
            </div>
        </div>
      </div>
      @endforeach
    </div>
      
    <!-- /.row -->

    <hr>

    <!-- Call to Action Section -->
    <div class="row mb-4">
      <div class="col-md-4">
        <a class="btn btn-lg btn-secondary btn-block" href="#">Up to home page</a>
      </div>
    </div>

  </div>
  <!-- /.container -->
@endsection