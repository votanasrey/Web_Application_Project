@extends('Container.html')

@section('html')
<div class="container-fluid">
    <div class="row no-gutter">
      <div class="d-none d-md-flex col-md-4 col-lg-6 bg-image"></div>
      <div class="col-md-8 col-lg-6">
        <div class="login d-flex align-items-center py-5">
          <div class="container">
            <div class="row">
              <div class="col-md-9 col-lg-8 mx-auto">
                <h3 class="login-heading mb-4">Welcome To Register!</h3>
                @if ($message = Session::get('success'))
                    <div class="alert alert-success">
                      <p>{{ $message }}</p>
                    </div>
                @endif
                @if ($errors->any())
                    <div class="alert alert-danger">
                    <strong>Whoop!</strong> There were some problems with your input. <br><br>
                    <ul>
                      @foreach ($errors->all() as $error)
                          <li>{{ $error }}</li>
                      @endforeach
                    </ul>
                    </div>
                @endif
                <form action="{{ route('users.store') }}" method="POST">
                  @csrf

                  {{-- email --}}
                  <div class="form-label-group">
                    <input type="email" name="email" id="email" value="{{ old('email') }}" class="form-control" placeholder="Email address" required autofocus>
                    <label for="email">Email address</label>
                  </div>

                  {{-- name --}}
                  <div class="form-label-group">
                    <input type="text" name="name" id="name" value="{{ old('name') }}" class="form-control" placeholder="Name" required>
                    <label for="name">Name</label>
                  </div>

                  {{-- gender --}}
                  <div class="form-label-group">
                    <select name="gender" id="gender" data-selected="Other" class="form-control" required>
                        @if (old('gender') != 'Male' && old('gender') != 'Female' && old('gender') != 'Other')
                           <option value="" hidden selected>Gender</option>
                           <option value="Male">Male</option>
                           <option value="Female">Female</option>
                           <option value="Other">Other</option>
                        @endif
                        @if (old('gender') == 'Male')
                           <option value="Male" selected>Male</option>
                           <option value="Female">Female</option>
                           <option value="Other">Other</option>
                        @endif
                        @if (old('gender') == 'Female')
                           <option value="Male">Male</option>
                           <option value="Female" selected>Female</option>
                           <option value="Other">Other</option>
                        @endif
                        @if (old('gender') == 'Other')
                           <option value="Male">Male</option>
                           <option value="Female">Female</option>
                           <option value="Other" selected>Other</option>
                        @endif
                    </select>
                  </div>

                  {{-- Birthday --}}
                  <div class="form-label-group">
                    <input type="date" name="dob" id="dob" value="{{ old('dob') }}" class="form-control" required>
                    <label for="dob">Birthday</label>
                  </div>

                  {{-- address --}}
                  <div class="form-label-group">
                    <input type="text" name="address" id="address" value="{{ old('address') }}" class="form-control" placeholder="Address" required>
                    <label for="address">Address</label>
                  </div>

                  {{-- password --}}
                  <div class="form-label-group">
                    <input type="password" name="password" id="password" value="{{ old('password') }}" class="form-control" placeholder="Password" required>
                    <label for="password">Password</label>
                  </div>

                  {{-- password --}}
                  <div class="form-label-group">
                    <input type="password" name="password_confirmation" id="password_confirmation" value="{{ old('password_confirmation') }}" class="form-control" placeholder="Confirm Password" required>
                    <label for="password_confirmation">Confirm Password</label>
                  </div>

                  {{-- Submit button --}}
                  <button class="btn btn-lg text-white btn-block btn-login text-uppercase font-weight-bold mb-2" type="submit">Register</button>

                  {{-- Go to login page --}}
                  <div class="text-center">
                    <a class="small" href="/users">Go To Login</a></div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>  
@endsection